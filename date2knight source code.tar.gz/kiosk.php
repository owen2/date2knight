<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="style.css" media="screen" />
        <link rel="stylesheet" href="print.css" media="print" />
    </head>
    <body>

        <div class="content bodywrap">
		    <?php
			    mysql_connect("mysql.owenjohnson.info", "lovematch","lovematch"); // There is a web based admin tool at mysql.owenjohnson.info. Use the user lovematch and the password lovematch to get in to edit questions and clear results.
			    mysql_query("USE `lovematch`");
			    $result = mysql_query("SELECT * FROM `responses` ORDER BY `name`;");
			    mysql_error();
			    ?><table><?php
                while ($row = mysql_fetch_array($result))
                {
                    echo("<tr>");
                    echo("<td>". $row['name'] ."</td>");
                    echo("<td>");
                    if ($row['paid'] == "paid"){echo('<a href="report.php?id='. $row['id'] .'">get report</a></td><td>');}else{echo('</td><td><a href="markpaid.php?id='. $row['id'] .'">mark as paid</a>');}
                    echo("</td>");
                    echo("</tr>");
                }					
		    ?></ul>
        
        </div>

    </body>

</html>
