

<?php error_reporting(E_ALL);
ini_set('display_errors', '1');
    
    mysql_connect("mysql.owenjohnson.info", "lovematch","lovematch");
    mysql_query("USE `lovematch`");

$sql = "UPDATE `lovematch`.`responses` SET `paid` = 'paid' WHERE `responses`.`id` =" .$_REQUEST['id'];
if(mysql_query($sql))
{
    header("location: kiosk.php");    
}
    ?><h1>SOMETHING WENT WRONG!</h1><p>There was an error marking as paid.</p><?php
    mysql_error();
    ?><br><?php
    print_r($_REQUEST); 
    ?><br><?php
    echo($sql);
?>
